package com.example.viisar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
