class Subject {
  final String id;
  final String name;
  final String classId;

  Subject({required this.id, required this.name, required this.classId});

  factory Subject.fromJson(Map<String, dynamic> json) {
    if (json['_id'] == null ||
        json['name'] == null ||
        json['classId'] == null) {
      throw Exception("Missing required fields in Subject JSON: $json");
    }

    return Subject(
      id: json['_id'],
      name: json['name'],
      classId: json['classId'],
    );
  }
}
