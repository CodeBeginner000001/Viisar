class HistoryModel {
  final String chapterId;
  final String chapterName;
  final String topicId;
  final String topicName;
  final String topicurl;

  HistoryModel({
    required this.chapterId,
    required this.chapterName,
    required this.topicId,
    required this.topicName,
    required this.topicurl,
  });

  factory HistoryModel.fromJson(Map<String, dynamic> json) {
    return HistoryModel(
      chapterId: json['chapterId']['_id'] ?? '',
      chapterName: json['chapterId']['name'] ?? '',
      topicId: json['topicId']['_id'] ?? '',
      topicName: json['topicId']['name'] ?? '',
      topicurl: json['topicId']['audioUrl'] ?? '',
    );
  }
}
