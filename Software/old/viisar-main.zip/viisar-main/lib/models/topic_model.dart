class Topic {
  final String id;
  final String name;
  final String chapterId;
  final String url;
  final String language;

  Topic({
    required this.id,
    required this.name,
    required this.chapterId,
    required this.url,
    this.language = "",
  });

  factory Topic.fromJson(Map<String, dynamic> json) {
    if (json['_id'] == null ||
        json['name'] == null ||
        json['chapterId'] == null) {
      throw Exception("Missing required fields in Topic JSON: $json");
    }

    return Topic(
      id: json['_id'],
      name: json['name'],
      chapterId: json['chapterId'],
      url: json['audioUrl'],
      language: json['lang'] ?? "",
    );
  }
}
