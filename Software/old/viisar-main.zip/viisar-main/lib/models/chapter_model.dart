class Chapter {
  final String id;
  final String name;
  final String subjectId;

  Chapter({required this.id, required this.name, required this.subjectId});

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['_id'],
      name: json['name'],
      subjectId: json['subjectId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'_id': id, 'name': name, 'subjectId': subjectId};
  }
}
