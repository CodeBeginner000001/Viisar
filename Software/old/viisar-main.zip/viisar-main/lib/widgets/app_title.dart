import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AppTitleText extends StatelessWidget {
  final String text;

  const AppTitleText({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      header: true,
      label: text,
      child: Text(
        text,
        style: AppTextStyles.headlineMedium(Colors.white),
        textAlign: TextAlign.center,
      ),
    );
  }
}
