import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AppInputField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final String semanticsLabel;

  const AppInputField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.semanticsLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      textField: true,
      label: semanticsLabel,
      child: TextField(
        controller: controller,
        style: AppTextStyles.inputField(Colors.black),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: AppTextStyles.labelMedium(Colors.grey),
          fillColor: Colors.white,
          filled: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 18,
          ),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}
