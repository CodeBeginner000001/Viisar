import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AppPasscodeField extends StatelessWidget {
  final Function(String) onChanged;

  const AppPasscodeField({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      textField: true,
      label: 'Enter 4 digit passcode',
      child: PinCodeTextField(
        length: 4,
        obscureText: true,
        animationType: AnimationType.fade,
        keyboardType: TextInputType.number,
        backgroundColor: Colors.transparent,
        pinTheme: PinTheme(
          shape: PinCodeFieldShape.box,
          borderRadius: BorderRadius.circular(8),
          fieldHeight: 60,
          fieldWidth: 60,
          activeColor: Colors.white,
          inactiveColor: Colors.white30,
          selectedColor: AppColors.primary,
          activeFillColor: Colors.transparent,
          inactiveFillColor: Colors.transparent,
          selectedFillColor: Colors.transparent,
        ),
        textStyle: AppTextStyles.inputField(Colors.white),
        animationDuration: const Duration(milliseconds: 300),
        enableActiveFill: false,
        onChanged: onChanged,
        appContext: context,
      ),
    );
  }
}
