import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AudioPlayerWidget extends StatefulWidget {
  final String audioUrl;
  const AudioPlayerWidget({required this.audioUrl, super.key});

  @override
  State<AudioPlayerWidget> createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  late AudioPlayer _player;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      await _player.setUrl(widget.audioUrl);
      _player.durationStream.listen((d) {
        if (d != null) {
          setState(() => _duration = d);
        }
      });
      _player.positionStream.listen((p) {
        setState(() => _position = p);
      });
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    _player.playing ? _player.pause() : _player.play();
  }

  void _seekForward() {
    final newPos = _position + const Duration(seconds: 10);
    _player.seek(newPos > _duration ? _duration : newPos);
  }

  void _seekBackward() {
    final newPos = _position - const Duration(seconds: 10);
    _player.seek(newPos < Duration.zero ? Duration.zero : newPos);
  }

  String _formatDuration(Duration d) {
    return d.toString().split('.').first.padLeft(8, "0");
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (_isLoading)
          const CircularProgressIndicator()
        else
          Column(
            children: [
              Semantics(
                button: true,
                label: 'Play or pause',
                hint: 'Double tap to toggle audio playback',
                excludeSemantics: true,
                child: GestureDetector(
                  onTap: _togglePlayPause,
                  child: CircleAvatar(
                    radius: 60,
                    backgroundColor: AppColors.primary,
                    child: StreamBuilder<PlayerState>(
                      stream: _player.playerStateStream,
                      builder: (context, snapshot) {
                        final isPlaying = snapshot.data?.playing ?? false;
                        return Icon(
                          isPlaying ? Icons.pause : Icons.play_arrow,
                          size: 64,
                          color: Colors.black,
                        );
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // Rewind and Forward buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Semantics(
                    label: 'Rewind 10 seconds',
                    hint: 'Double tap to go 10 seconds back',
                    button: true,
                    excludeSemantics: true,
                    child: GestureDetector(
                      onTap: _seekBackward,
                      child: CircleAvatar(
                        radius: 32,
                        backgroundColor: Colors.white24,
                        child: const Icon(
                          Icons.replay_10,
                          size: 32,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 40),
                  Semantics(
                    label: 'Forward 10 seconds',
                    hint: 'Double tap to go 10 seconds forward',
                    button: true,
                    excludeSemantics: true,
                    child: GestureDetector(
                      onTap: _seekForward,
                      child: CircleAvatar(
                        radius: 32,
                        backgroundColor: Colors.white24,
                        child: const Icon(
                          Icons.forward_10,
                          size: 32,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 40),

              Semantics(
                label: 'Audio progress',
                hint:
                    'Swipe up or down to adjust, left or right to explore current position',
                child: Slider(
                  activeColor: AppColors.primary,
                  inactiveColor: Colors.white24,
                  min: 0,
                  max: _duration.inSeconds.toDouble(),
                  value:
                      _position.inSeconds
                          .clamp(0, _duration.inSeconds)
                          .toDouble(),
                  onChanged: (value) {
                    _player.seek(Duration(seconds: value.toInt()));
                  },
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _formatDuration(_position),
                      style: AppTextStyles.labelMedium(Colors.white),
                    ),
                    Text(
                      _formatDuration(_duration),
                      style: AppTextStyles.labelMedium(Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
      ],
    );
  }
}
