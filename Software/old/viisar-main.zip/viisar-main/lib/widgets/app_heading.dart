import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AppHeading extends StatelessWidget {
  final String text;

  const AppHeading({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: text,
      header: true,
      child: Text(
        text,
        style: AppTextStyles.headlineLarge(Colors.white),
        textAlign: TextAlign.center,
      ),
    );
  }
}
