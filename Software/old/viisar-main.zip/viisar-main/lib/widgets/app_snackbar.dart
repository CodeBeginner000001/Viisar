import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

void showCustomSnackbar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: Colors.black87,
      content: Text(message, style: AppTextStyles.snackBarText(Colors.white)),
    ),
  );
}
