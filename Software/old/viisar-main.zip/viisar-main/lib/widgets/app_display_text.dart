import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

class AppDisplayText extends StatelessWidget {
  final String text;
  final Color color;

  const AppDisplayText({super.key, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: text,
      child: Text(
        text,
        style: AppTextStyles.titleLarge(color),
        textAlign: TextAlign.center,
      ),
    );
  }
}
