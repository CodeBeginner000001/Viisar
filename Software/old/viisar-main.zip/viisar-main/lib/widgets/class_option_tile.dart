import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';
import 'package:viisar/models/class_model.dart';

class ClassOptionTile extends StatelessWidget {
  final Class classItem;
  final bool isSelected;
  final VoidCallback onTap;

  const ClassOptionTile({
    super.key,
    required this.classItem,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label:
          'Class option: ${classItem.name}, ${isSelected ? "selected" : "not selected"}',
      selected: isSelected,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
          decoration: BoxDecoration(
            color:
                isSelected
                    ? AppColors
                        .primary // bright highlight
                    : AppColors.darkCard, // darker shade for unselected
            borderRadius: BorderRadius.circular(24),
            border:
                isSelected ? Border.all(color: Colors.white, width: 2) : null,
          ),
          child: Center(
            child: Text(
              classItem.name,
              style: AppTextStyles.labelMedium(Colors.white),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}
