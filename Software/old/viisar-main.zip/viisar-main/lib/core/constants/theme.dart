import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';

final ThemeData darkTheme = ThemeData(
  brightness: Brightness.dark,
  scaffoldBackgroundColor: AppColors.secondary,
  primaryColor: AppColors.primary,
  colorScheme: const ColorScheme.dark(
    primary: AppColors.primary,
    secondary: AppColors.accent,
    background: AppColors.secondary,
    surface: AppColors.surface,
    error: AppColors.error,
    onPrimary: Colors.white,
    onSecondary: Colors.white,
    onBackground: Colors.white,
    onSurface: Colors.white,
    onError: Colors.white,
  ),
  textTheme: TextTheme(
    headlineLarge: AppTextStyles.headlineLarge(AppColors.text),
    titleLarge: AppTextStyles.titleLarge(AppColors.text),
    labelMedium: AppTextStyles.labelMedium(AppColors.text),
    bodyMedium: AppTextStyles.labelMedium(AppColors.text),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: AppTextStyles.buttonText(Colors.white),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: AppColors.surface,
    hintStyle: TextStyle(color: Colors.grey[500]),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: AppColors.secondary,
    elevation: 0,
    iconTheme: const IconThemeData(color: Colors.white),
    titleTextStyle: AppTextStyles.titleLarge(Colors.white),
  ),
  fontFamily: 'Atkinson-Hyperlegible',
);
