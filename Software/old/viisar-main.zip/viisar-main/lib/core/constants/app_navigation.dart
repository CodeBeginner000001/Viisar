import 'package:flutter/material.dart';

enum TransitionType { fade, slideFromRight, slideFromBottom }

class AnimatedPageRoute<T> extends PageRouteBuilder<T> {
  final Widget page;
  final TransitionType transitionType;

  AnimatedPageRoute({
    required this.page,
    this.transitionType = TransitionType.fade,
  }) : super(
         pageBuilder: (context, animation, secondaryAnimation) => page,
         transitionDuration: const Duration(milliseconds: 400),
         reverseTransitionDuration: const Duration(milliseconds: 300),
         transitionsBuilder: (context, animation, secondaryAnimation, child) {
           switch (transitionType) {
             case TransitionType.slideFromRight:
               return SlideTransition(
                 position: Tween<Offset>(
                   begin: const Offset(1.0, 0.0),
                   end: Offset.zero,
                 ).animate(animation),
                 child: child,
               );
             case TransitionType.slideFromBottom:
               return SlideTransition(
                 position: Tween<Offset>(
                   begin: const Offset(0.0, 1.0),
                   end: Offset.zero,
                 ).animate(animation),
                 child: child,
               );
             case TransitionType.fade:
               return FadeTransition(opacity: animation, child: child);
           }
         },
       );
}
