import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTextStyles {
  static TextStyle headlineLarge(Color color) =>
      GoogleFonts.atkinsonHyperlegible(
        fontSize: 48,
        fontWeight: FontWeight.bold,
        color: color,
      );

  static TextStyle headlineMedium(Color color) =>
      GoogleFonts.atkinsonHyperlegible(
        fontSize: 36,
        fontWeight: FontWeight.w600,
        color: color,
      );

  static TextStyle titleLarge(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 32,
    fontWeight: FontWeight.w600,
    color: color,
  );

  static TextStyle labelMedium(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 28,
    fontWeight: FontWeight.w500,
    color: color,
  );

  static TextStyle inputField(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 30,
    fontWeight: FontWeight.w500,
    letterSpacing: 1.2,
    color: color,
  );

  static TextStyle errorText() =>
      GoogleFonts.atkinsonHyperlegible(fontSize: 22, color: Colors.red);

  static TextStyle buttonText(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 30,
    fontWeight: FontWeight.bold,
    color: color,
  );

  static TextStyle snackBarText(Color color) =>
      GoogleFonts.atkinsonHyperlegible(
        fontSize: 24,
        fontWeight: FontWeight.w500,
        color: color,
      );

  // Optional extras (for flexibility)
  static TextStyle subtitle(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 26,
    fontWeight: FontWeight.w400,
    color: color,
  );

  static TextStyle caption(Color color) => GoogleFonts.atkinsonHyperlegible(
    fontSize: 20,
    fontWeight: FontWeight.w400,
    color: color.withOpacity(0.8),
  );
}
