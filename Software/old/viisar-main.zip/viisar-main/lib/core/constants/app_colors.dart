import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(
    0xFF9C7B3C,
  ); // Gold-brown from logo (head + text)
  static const Color secondary = Color(
    0xFF1C1C1C,
  ); // Very dark grey (used in text)
  static const Color background = Color(
    0xFFFFFFFF,
  ); // White background as per logo
  static const Color surface = Color(
    0xFFF5F5F5,
  ); // Light grey for cards/surfaces
  static const Color text = Color(0xFF1C1C1C); // Almost black text
  static const Color accent = Color(0xFF9C7B3C); // Matching gold tone
  static const Color error = Color(0xFFE53935); // Consistent error red
  static const darkCard = Color(0xFF2A2A2A); // dark grey background
}
