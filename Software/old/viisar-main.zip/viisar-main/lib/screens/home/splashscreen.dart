import 'package:flutter/material.dart';
import 'package:viisar/screens/auth/user_selection_screen.dart';
import 'package:viisar/screens/home/homescreen.dart';
import 'package:viisar/services/shared_pref.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';

class Splashscreen extends StatelessWidget {
  const Splashscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splash: Center(
        child: Image.asset(
          'assets/images/logo.jpg',
          fit: BoxFit.contain,
          height: 300,
        ),
      ),
      nextScreen: FutureBuilder<bool>(
        future: SharedPrefsService().isUserLoggedIn(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text("Error checking login status"));
          }

          final bool isLoggedIn = snapshot.data ?? false;

          return isLoggedIn ? const HomeScreen() : UserSelectionScreen();
        },
      ),
      splashIconSize: 300, // Adjust the size of the logo
      backgroundColor: Color.fromRGBO(252, 252, 252, 255),
      pageTransitionType: PageTransitionType.fade, // Fade transition
      duration: 2000, // Show splash for 3 seconds
    );
  }
}
