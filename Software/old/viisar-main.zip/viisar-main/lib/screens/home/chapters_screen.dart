import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/core/constants/app_text_styles.dart';
import 'package:viisar/models/chapter_model.dart';
import 'package:viisar/screens/topics/topics_screen.dart';
import 'package:viisar/services/subject_service.dart';
import 'package:viisar/widgets/minimalist_card.dart'; // Reuse MinimalistCard

class ChapterScreen extends StatefulWidget {
  final String subjectId;
  final String subjectName;

  const ChapterScreen({
    super.key,
    required this.subjectId,
    required this.subjectName,
  });

  @override
  _ChapterScreenState createState() => _ChapterScreenState();
}

class _ChapterScreenState extends State<ChapterScreen> {
  late Future<List<Chapter>> _chapters;

  @override
  void initState() {
    super.initState();

    _chapters = SubjectService().fetchChaptersBySubject(widget.subjectId);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 4000), () {
        SemanticsService.announce(
          'This is the Chapter Selection screen for ${widget.subjectName}.',
          TextDirection.ltr,
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        centerTitle: true,
        title: Text(
          widget.subjectName,
          style: AppTextStyles.headlineMedium(Colors.white),
        ),
        elevation: 5, // Adds shadow to the AppBar
        toolbarHeight: 80,
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: FutureBuilder<List<Chapter>>(
            future: _chapters,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }

              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text('No chapters available'));
              }

              final chapters = snapshot.data!;

              return GridView.builder(
                itemCount: chapters.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 1, // Single chapter per row
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  childAspectRatio: 2.5, // Bigger boxes
                ),
                itemBuilder: (context, index) {
                  final chapter = chapters[index];
                  return MinimalistCard(
                    title: chapter.name,
                    onTap: () {
                      Navigator.push(
                        context,
                        AnimatedPageRoute(
                          page: TopicScreen(
                            chapterName: chapter.name,
                            chapterid: chapter.id,
                          ),
                          transitionType: TransitionType.slideFromRight,
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
