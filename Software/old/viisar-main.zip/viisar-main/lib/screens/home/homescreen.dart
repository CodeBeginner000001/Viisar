import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/home/user_details_screen.dart';
import 'package:viisar/screens/home/subjects_screen.dart';
import 'package:viisar/screens/topics/audio_screen.dart';
import 'package:viisar/services/bookmark_service.dart';
import 'package:viisar/widgets/app_heading.dart';
import 'package:viisar/widgets/app_snackbar.dart';
import 'package:viisar/widgets/minimalist_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Profile button
                Row(
                  children: [
                    Semantics(
                      label: 'Profile button',
                      hint: 'Double tap to open profile',
                      button: true,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            AnimatedPageRoute(
                              page: const UserProfileScreen(),
                              transitionType: TransitionType.slideFromBottom,
                            ),
                          );
                        },
                        borderRadius: BorderRadius.circular(50),
                        child: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppColors.primary,
                              width: 2,
                            ),
                          ),
                          child: const Icon(
                            Icons.person_outline,
                            color: AppColors.primary,
                            size: 26,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 40),

                Semantics(
                  label: 'Welcome to Viisaaar',
                  child: ExcludeSemantics(
                    child: AppHeading(text: 'Welcome to Viisar'),
                  ),
                ),

                const SizedBox(height: 40),

                Column(
                  children: [
                    MinimalistCard(
                      title: 'Resume your learning',
                      onTap: () async {
                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder:
                              (context) => const Center(
                                child: CircularProgressIndicator(),
                              ),
                        );

                        final bookmark = await BookmarkService.getBookmark();

                        Navigator.pop(context);

                        if (bookmark != null) {
                          Navigator.push(
                            context,
                            AnimatedPageRoute(
                              page: AudioPlayerScreen(
                                audioid: bookmark.topicId,
                                audioName: bookmark.topicName,
                                audioUrl: bookmark.topicurl,
                              ),
                              transitionType: TransitionType.slideFromRight,
                            ),
                          );
                        } else {
                          showCustomSnackbar(context, 'No bookmark found.');
                        }
                      },
                    ),
                    const SizedBox(height: 24),
                    MinimalistCard(
                      title: 'Start something new',
                      onTap: () {
                        Navigator.push(
                          context,
                          AnimatedPageRoute(
                            page: SubjectScreen(),
                            transitionType: TransitionType.slideFromRight,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
