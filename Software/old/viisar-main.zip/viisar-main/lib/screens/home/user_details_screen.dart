import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/auth/class_select.dart';
import 'package:viisar/services/authorization.dart';
import 'package:viisar/services/profile_fetch.dart';
import 'package:viisar/widgets/app_display_text.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/widgets/app_info_tile.dart';
import 'package:viisar/widgets/app_title.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  Map<String, dynamic>? userDetails;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchDetails();
  }

  Future<void> _fetchDetails() async {
    final data = await UserService.getUserDetails();
    setState(() {
      userDetails = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child:
              _loading
                  ? const Center(child: CircularProgressIndicator())
                  : userDetails == null
                  ? const Center(
                    child: AppDisplayText(
                      text: 'Failed to load user details',
                      color: Colors.white,
                    ),
                  )
                  : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Center(
                        child: AppTitleText(text: 'Profile Details'),
                      ),
                      const SizedBox(height: 40),
                      InfoTile(
                        label: 'Username',
                        value: userDetails?['username'],
                      ),
                      const SizedBox(height: 20),
                      InfoTile(label: 'Name', value: userDetails?['name']),
                      const SizedBox(height: 20),
                      InfoTile(
                        label: 'Class',
                        value: userDetails?['classId']?['name'] ?? 'N/A',
                        onTap: () {
                          Navigator.push(
                            context,
                            AnimatedPageRoute(
                              page: ClassSelectionScreen(),
                              transitionType: TransitionType.fade,
                            ),
                          );
                        },
                      ),

                      const Spacer(),
                      Semantics(
                        button: true,
                        label: 'Logout Button',
                        child: AppButton(
                          text: 'Logout',
                          color: Colors.red,
                          isLoading: false,
                          onPressed: () {
                            AuthService().logout(context);
                          },
                        ),
                      ),
                    ],
                  ),
        ),
      ),
    );
  }
}
