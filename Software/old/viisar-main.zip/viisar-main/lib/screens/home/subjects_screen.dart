import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/core/constants/app_text_styles.dart';
import 'package:viisar/models/subject_model.dart';
import 'package:viisar/screens/home/chapters_screen.dart';
import 'package:viisar/services/subject_service.dart';
import 'package:viisar/services/shared_pref.dart';
import 'package:viisar/widgets/minimalist_card.dart';

class SubjectScreen extends StatefulWidget {
  const SubjectScreen({super.key});

  @override
  _SubjectScreenState createState() => _SubjectScreenState();
}

class _SubjectScreenState extends State<SubjectScreen> {
  Future<List<Subject>>? _subjects;

  @override
  void initState() {
    super.initState();
    _loadSubjectsFromSharedPrefs();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 4000), () {
        SemanticsService.announce(
          'This is the subjects Selection screen.',
          TextDirection.ltr,
        );
      });
    });
  }

  Future<void> _loadSubjectsFromSharedPrefs() async {
    final classId = await SharedPrefsService.getClassId();

    if (classId != null) {
      final subjectsFuture = SubjectService().fetchSubjectsByClassId(classId);
      setState(() {
        _subjects = subjectsFuture;
      });
    } else {
      setState(() {
        _subjects = Future.error('No classId found in storage.');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        centerTitle: true,
        title: Text(
          "Subjects",
          style: AppTextStyles.headlineMedium(Colors.white),
        ),
        elevation: 5,
        toolbarHeight: 80,
      ),
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child:
              _subjects == null
                  ? const Center(child: CircularProgressIndicator())
                  : FutureBuilder<List<Subject>>(
                    future: _subjects,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      }

                      if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return const Center(
                          child: Text('No subjects available'),
                        );
                      }

                      final subjects = snapshot.data!;

                      return GridView.builder(
                        itemCount: subjects.length,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 1,
                              crossAxisSpacing: 20,
                              mainAxisSpacing: 20,
                              childAspectRatio: 2.5,
                            ),
                        itemBuilder: (context, index) {
                          final subject = subjects[index];
                          return MinimalistCard(
                            title: subject.name,
                            onTap: () {
                              Navigator.push(
                                context,
                                AnimatedPageRoute(
                                  page: ChapterScreen(
                                    subjectId: subject.id,
                                    subjectName: subject.name,
                                  ),
                                  transitionType: TransitionType.slideFromRight,
                                ),
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
        ),
      ),
    );
  }
}
