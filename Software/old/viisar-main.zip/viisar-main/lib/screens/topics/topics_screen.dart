import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';
import 'package:viisar/models/topic_model.dart';
import 'package:viisar/screens/topics/audio_screen.dart';
import 'package:viisar/services/subject_service.dart';
import 'package:viisar/widgets/minimalist_card.dart';

class TopicScreen extends StatefulWidget {
  final String chapterid;
  final String chapterName;

  const TopicScreen({
    required this.chapterid,
    required this.chapterName,
    super.key,
  });

  @override
  _TopicScreenState createState() => _TopicScreenState();
}

class _TopicScreenState extends State<TopicScreen> {
  Future<List<Topic>>? _topics;
  bool _isHindiSelected = false; // Toggle for Hindi/English selection

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    print('Fetching topics for chapterId: ${widget.chapterid}');
    final topicsFuture = SubjectService().fetchTopicsByChapterId(
      widget.chapterid,
    );
    setState(() {
      _topics = topicsFuture;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        centerTitle: true,
        title: Text(
          widget.chapterName,
          style: AppTextStyles.headlineMedium(Colors.white),
        ),
        elevation: 5,
        toolbarHeight: 80,
      ),
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Column(
          children: [
            // Topic List
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child:
                    _topics == null
                        ? const Center(child: CircularProgressIndicator())
                        : FutureBuilder<List<Topic>>(
                          future: _topics,
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            }

                            if (snapshot.hasError) {
                              return Center(
                                child: Text('Error: ${snapshot.error}'),
                              );
                            }

                            if (!snapshot.hasData || snapshot.data!.isEmpty) {
                              return const Center(
                                child: Text('No topics available'),
                              );
                            }

                            final topics = snapshot.data!;
                            // Filter topics based on language selection
                            final filteredTopics =
                                topics
                                    .where(
                                      (topic) =>
                                          topic.language ==
                                          (_isHindiSelected ? 'hi' : 'en'),
                                    )
                                    .toList();

                            return GridView.builder(
                              itemCount: filteredTopics.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 1,
                                    crossAxisSpacing: 20,
                                    mainAxisSpacing: 20,
                                    childAspectRatio: 2.5,
                                  ),
                              itemBuilder: (context, index) {
                                final topic = filteredTopics[index];
                                return MinimalistCard(
                                  title: topic.name,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) => AudioPlayerScreen(
                                              audioName: topic.name,
                                              audioUrl: topic.url,
                                              audioid: topic.id,
                                            ),
                                      ),
                                    );
                                  },
                                );
                              },
                            );
                          },
                        ),
              ),
            ),
            // Toggle button for language selection (Hindi/English) at the bottom
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _isHindiSelected = false; // Switch to English
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          _isHindiSelected
                              ? AppColors.surface
                              : AppColors.primary,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                    ),
                    child: Text(
                      'English',
                      style: TextStyle(
                        color: _isHindiSelected ? Colors.black : Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _isHindiSelected = true;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          !_isHindiSelected
                              ? AppColors.surface
                              : AppColors.primary,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                    ),
                    child: Text(
                      'Hindi',
                      style: TextStyle(
                        color: !_isHindiSelected ? Colors.black : Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
