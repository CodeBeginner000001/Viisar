import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_text_styles.dart';
import 'package:viisar/widgets/app_snackbar.dart';
import 'package:viisar/widgets/audio_player.dart';
import 'package:viisar/services/bookmark_service.dart';

class AudioPlayerScreen extends StatelessWidget {
  final String audioUrl;
  final String audioName;
  final String audioid;

  const AudioPlayerScreen({
    required this.audioUrl,
    required this.audioName,
    required this.audioid,
    super.key,
  });

  void handleBookmark(BuildContext context) async {
    final success = await BookmarkService.updateBookmark(audioid);
    if (context.mounted) {
      showCustomSnackbar(
        context,
        success ? 'Bookmark added!' : 'Failed to add bookmark.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      floatingActionButton: Semantics(
        label: 'Bookmark this audio',
        hint: 'Double tap to bookmark this audio for later',
        button: true,
        child: Container(
          width: 100.0,
          height: 100.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: IconButton(
            icon: const Icon(
              Icons.bookmark_add_rounded,
              color: Colors.black,
              size: 60.0,
            ),
            onPressed: () => handleBookmark(context),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            Semantics(
              label: 'Audio Title',
              hint: 'Title of the currently playing audio',
              child: Center(
                child: Text(
                  audioName,
                  style: AppTextStyles.headlineMedium(Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            const SizedBox(height: 60),
            Semantics(
              label: 'Audio player controls',
              hint: 'Use the controls to play, pause, rewind, or forward',
              container: true,
              child: AudioPlayerWidget(audioUrl: audioUrl),
            ),
          ],
        ),
      ),
    );
  }
}
