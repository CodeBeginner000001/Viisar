import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/models/class_model.dart';
import 'package:viisar/screens/home/homescreen.dart';
import 'package:viisar/services/class_service.dart';
import 'package:viisar/services/shared_pref.dart';
import 'package:viisar/widgets/app_snackbar.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/class_option_tile.dart';
import 'package:viisar/widgets/app_display_text.dart';

class ClassSelectionScreen extends StatefulWidget {
  const ClassSelectionScreen({super.key});

  @override
  State<ClassSelectionScreen> createState() => _ClassSelectionScreenState();
}

class _ClassSelectionScreenState extends State<ClassSelectionScreen> {
  List<Class> _classes = [];
  String? _selectedClassId;
  bool _isLoading = true;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _fetchClasses();
  }

  Future<void> _fetchClasses() async {
    try {
      setState(() => _isLoading = true);
      final fetched = await ClassService.fetchAllClasses();

      if (fetched.isEmpty) {
        throw Exception('No classes found');
      }

      setState(() {
        _classes = fetched;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        showCustomSnackbar(context, 'Failed to load classes');
      }
    }
  }

  Future<void> _submitClass() async {
    if (_selectedClassId == null) return;

    setState(() => _isSubmitting = true);
    final success = await ClassService.updateClass(_selectedClassId!);
    setState(() => _isSubmitting = false);

    if (success) {
      await SharedPrefsService.saveUserData(
        token: await SharedPrefsService.getToken() ?? '',
        userId: await SharedPrefsService.getUserId() ?? '',
        classId: _selectedClassId!,
        username: await SharedPrefsService.getName() ?? '',
      );
      showCustomSnackbar(context, 'Class updated successfully');

      Navigator.pushReplacement(
        context,
        AnimatedPageRoute(
          page: const HomeScreen(),
          transitionType: TransitionType.fade,
        ),
      );
    } else {
      showCustomSnackbar(context, 'Failed to update class');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Semantics(
          container: true,
          label: 'Class selection screen',
          child:
              _isLoading
                  ? const Center(
                    child: CircularProgressIndicator(
                      semanticsLabel: 'Loading classes',
                    ),
                  )
                  : Column(
                    children: [
                      const SizedBox(height: 20),
                      const AppDisplayText(
                        text: 'Select Your Class',
                        color: Colors.white,
                      ),
                      const SizedBox(height: 20),
                      Expanded(
                        child: ListView.builder(
                          itemCount: _classes.length,
                          itemBuilder: (context, index) {
                            final classItem = _classes[index];
                            return Semantics(
                              selected: classItem.id == _selectedClassId,
                              button: true,
                              label:
                                  'Class ${classItem.name}, ${classItem.id == _selectedClassId ? "selected" : "not selected"}',
                              child: ClassOptionTile(
                                classItem: classItem,
                                isSelected: classItem.id == _selectedClassId,
                                onTap: () {
                                  setState(() {
                                    _selectedClassId = classItem.id;
                                  });
                                },
                              ),
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 30,
                        ),
                        child: AppButton(
                          text: 'Submit',
                          isLoading: _isSubmitting,
                          onPressed:
                              _selectedClassId == null ? null : _submitClass,
                        ),
                      ),
                    ],
                  ),
        ),
      ),
    );
  }
}
