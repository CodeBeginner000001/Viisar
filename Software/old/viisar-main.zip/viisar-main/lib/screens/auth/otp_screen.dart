// import 'package:flutter/material.dart';
// import 'package:viisar/core/constants/app_colors.dart';
// import 'package:viisar/core/constants/app_text_styles.dart';
// import 'package:viisar/services/auth_service.dart';
// import 'package:pin_code_fields/pin_code_fields.dart';
// import 'user_details_screen.dart';

// class OTPScreen extends StatefulWidget {
//   final String phone;
//   const OTPScreen({super.key, required this.phone});

//   @override
//   State<OTPScreen> createState() => _OTPScreenState();
// }

// class _OTPScreenState extends State<OTPScreen> {
//   final otpController = TextEditingController();
//   final FocusNode _otpFocusNode = FocusNode();
//   bool loading = false;
//   bool resendLoading = false;
//   bool _hasError = false;
//   String _errorMessage = '';

//   @override
//   void dispose() {
//     _otpFocusNode.dispose();
//     otpController.dispose();
//     super.dispose();
//   }

//   void verifyOtp() async {
//     if (otpController.text.isEmpty || otpController.text.length < 4) {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Please enter the complete 4-digit OTP';
//       });
//       return;
//     }

//     setState(() {
//       loading = true;
//       _hasError = false;
//     });

//     final result = await AuthService.verifyOtp(
//       widget.phone,
//       otpController.text,
//     );
//     setState(() => loading = false);

//     if (result == true && mounted) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(
//           builder: (_) => UserDetailsScreen(phone: widget.phone),
//         ),
//       );
//     } else {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Invalid or expired OTP. Please try again.';
//       });

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text(_errorMessage),
//           backgroundColor: Colors.red,
//           behavior: SnackBarBehavior.floating,
//           margin: const EdgeInsets.all(16),
//         ),
//       );
//     }
//   }

//   void resendOtp() async {
//     setState(() {
//       resendLoading = true;
//       _hasError = false;
//     });

//     bool success = await AuthService.sendOtp(widget.phone);
//     setState(() => resendLoading = false);

//     if (success && mounted) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('New OTP has been sent'),
//           backgroundColor: Colors.green,
//           behavior: SnackBarBehavior.floating,
//           margin: EdgeInsets.all(16),
//         ),
//       );
//     } else {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Failed to send OTP. Please try again.';
//       });

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text(_errorMessage),
//           backgroundColor: Colors.red,
//           behavior: SnackBarBehavior.floating,
//           margin: const EdgeInsets.all(16),
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);

//     return Scaffold(
//       backgroundColor: theme.colorScheme.background,
//       body: Semantics(
//         label: 'OTP verification screen',
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Semantics(
//                   header: true,
//                   child: Text(
//                     'Verify Your Number',
//                     style: AppTextStyles.headlineLarge(
//                       theme.colorScheme.onBackground,
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//                 Semantics(
//                   hint: 'Enter the OTP code sent to your phone',
//                   child: Text(
//                     'Enter the 4-digit code sent to:',
//                     style: AppTextStyles.titleLarge(
//                       theme.colorScheme.onBackground.withOpacity(0.9),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Text(
//                   widget.phone,
//                   style: AppTextStyles.titleLarge(AppColors.primary),
//                 ),
//                 const SizedBox(height: 40),

//                 // Enhanced OTP field with accessibility
//                 Semantics(
//                   label: 'OTP input field, 4 digits',
//                   textField: true,
//                   hint: 'Enter the 4-digit verification code',
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Verification Code',
//                         style: AppTextStyles.labelMedium(
//                           theme.colorScheme.onBackground,
//                         ),
//                       ),
//                       const SizedBox(height: 12),
//                       FocusScope(
//                         child: Semantics(
//                           label: 'OTP input field, 4 digits',
//                           child: PinCodeTextField(
//                             appContext: context,
//                             length: 4,
//                             controller: otpController,
//                             focusNode: _otpFocusNode,
//                             obscureText: false,
//                             animationType: AnimationType.fade,
//                             keyboardType: TextInputType.number,
//                             autoFocus: true,
//                             pinTheme: PinTheme(
//                               shape: PinCodeFieldShape.box,
//                               borderRadius: BorderRadius.circular(20),
//                               fieldHeight: 70,
//                               fieldWidth: 70,
//                               borderWidth: 2,
//                               activeColor: AppColors.primary,
//                               inactiveColor:
//                                   _hasError ? Colors.red : Colors.grey.shade300,
//                               selectedColor: AppColors.primary,
//                               activeFillColor: theme.colorScheme.surface,
//                               inactiveFillColor: theme.colorScheme.surface,
//                               selectedFillColor: theme.colorScheme.surface
//                                   .withOpacity(0.9),
//                               errorBorderColor: Colors.red,
//                             ),
//                             animationDuration: const Duration(
//                               milliseconds: 300,
//                             ),
//                             backgroundColor: Colors.transparent,
//                             enableActiveFill: true,
//                             textStyle: TextStyle(
//                               fontSize: 28,
//                               fontWeight: FontWeight.bold,
//                               color: theme.colorScheme.onSurface,
//                             ),
//                             onChanged: (value) {
//                               setState(() {
//                                 _hasError = false;
//                               });
//                             },
//                             beforeTextPaste: (text) => true,
//                             pastedTextStyle: const TextStyle(
//                               fontSize: 28,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                       ),
//                       if (_hasError)
//                         Padding(
//                           padding: const EdgeInsets.only(top: 8.0, left: 8.0),
//                           child: Text(
//                             _errorMessage,
//                             style: const TextStyle(
//                               color: Colors.red,
//                               fontSize: 16,
//                             ),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//                 const SizedBox(height: 48),

//                 Semantics(
//                   label: 'Verify OTP button',
//                   button: true,
//                   enabled: !loading,
//                   hint: 'Double tap to verify the code you entered',
//                   child: SizedBox(
//                     width: double.infinity,
//                     height: 64,
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: AppColors.primary,
//                         foregroundColor: Colors.white,
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         elevation: 2,
//                         padding: const EdgeInsets.symmetric(vertical: 12),
//                         textStyle: const TextStyle(
//                           fontSize: 22,
//                           fontWeight: FontWeight.bold,
//                           letterSpacing: 0.5,
//                         ),
//                       ),
//                       onPressed: loading ? null : verifyOtp,
//                       child:
//                           loading
//                               ? Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   const SizedBox(
//                                     width: 24,
//                                     height: 24,
//                                     child: CircularProgressIndicator(
//                                       color: Colors.white,
//                                       strokeWidth: 3,
//                                     ),
//                                   ),
//                                   const SizedBox(width: 16),
//                                   Text(
//                                     'Verifying...',
//                                     style: AppTextStyles.titleLarge(
//                                       Colors.white,
//                                     ),
//                                   ),
//                                 ],
//                               )
//                               : Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   const Icon(
//                                     Icons.check_circle_outline,
//                                     size: 24,
//                                   ),
//                                   const SizedBox(width: 12),
//                                   Text(
//                                     'Verify Code',
//                                     style: AppTextStyles.titleLarge(
//                                       Colors.white,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 24),

//                 Semantics(
//                   label: 'Resend OTP button',
//                   button: true,
//                   enabled: !resendLoading,
//                   hint: 'Double tap to request a new verification code',
//                   child: SizedBox(
//                     width: double.infinity,
//                     height: 64,
//                     child: OutlinedButton(
//                       onPressed: resendLoading ? null : resendOtp,
//                       style: OutlinedButton.styleFrom(
//                         side: BorderSide(color: AppColors.primary, width: 2),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         padding: const EdgeInsets.symmetric(vertical: 12),
//                         textStyle: const TextStyle(
//                           fontSize: 20,
//                           fontWeight: FontWeight.w600,
//                           letterSpacing: 0.5,
//                         ),
//                       ),
//                       child:
//                           resendLoading
//                               ? Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   SizedBox(
//                                     width: 24,
//                                     height: 24,
//                                     child: CircularProgressIndicator(
//                                       color: AppColors.primary,
//                                       strokeWidth: 3,
//                                     ),
//                                   ),
//                                   const SizedBox(width: 16),
//                                   Text(
//                                     'Sending...',
//                                     style: TextStyle(
//                                       color: AppColors.primary,
//                                       fontSize: 20,
//                                       fontWeight: FontWeight.w600,
//                                     ),
//                                   ),
//                                 ],
//                               )
//                               : Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   Icon(
//                                     Icons.refresh,
//                                     size: 24,
//                                     color: AppColors.primary,
//                                   ),
//                                   const SizedBox(width: 12),
//                                   Text(
//                                     'Resend Code',
//                                     style: TextStyle(
//                                       color: AppColors.primary,
//                                       fontSize: 20,
//                                       fontWeight: FontWeight.w600,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
