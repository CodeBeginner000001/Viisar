import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/auth/generated_username.dart';
import 'package:viisar/services/authorization.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/app_heading.dart';
import 'package:viisar/widgets/app_input_field.dart';
import 'package:viisar/widgets/app_snackbar.dart';

class UsernameGeneratorScreen extends StatefulWidget {
  const UsernameGeneratorScreen({super.key});

  @override
  State<UsernameGeneratorScreen> createState() =>
      _UsernameGeneratorScreenState();
}

class _UsernameGeneratorScreenState extends State<UsernameGeneratorScreen> {
  final TextEditingController _nameController = TextEditingController();
  bool _isLoading = false;

  void _showCustomSnackbar(String message) {
    showCustomSnackbar(context, message);
  }

  void _handleGenerate() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;

    setState(() => _isLoading = true);

    final userdetails = await AuthService().generateUsername(name);
    print("userdetails: $userdetails");

    setState(() => _isLoading = false);

    if (userdetails != null &&
        userdetails['username'] != null &&
        userdetails['userId'] != null) {
      Navigator.push(
        context,
        AnimatedPageRoute(
          page: UsernameResultScreen(
            username: userdetails['username']!,
            userid: userdetails['userId']!,
          ),
          transitionType: TransitionType.fade,
        ),
      );
    } else {
      _showCustomSnackbar("Failed to generate username. Try again.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const AppHeading(text: 'Enter your name'),
                const SizedBox(height: 40),
                AppInputField(
                  controller: _nameController,
                  hintText: 'Type your name',
                  semanticsLabel: 'Enter your name',
                ),
                const SizedBox(height: 30),
                AppButton(
                  text: 'Generate Username',
                  onPressed: _handleGenerate,
                  isLoading: _isLoading,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
