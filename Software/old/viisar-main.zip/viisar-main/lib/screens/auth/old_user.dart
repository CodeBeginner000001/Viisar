import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/home/homescreen.dart';
import 'package:viisar/widgets/app_heading.dart';
import 'package:viisar/widgets/app_input_field.dart';
import 'package:viisar/widgets/app_passcode_field.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/app_snackbar.dart';
import 'package:viisar/services/authorization.dart';

class OldUser extends StatefulWidget {
  const OldUser({super.key});

  @override
  State<OldUser> createState() => _OldUserState();
}

class _OldUserState extends State<OldUser> {
  final _usernameController = TextEditingController();
  String _passcode = '';
  bool _isLoading = false;

  Future<void> _onLogin() async {
    final username = _usernameController.text.trim();

    if (username.isEmpty || _passcode.length != 4) {
      showCustomSnackbar(
        context,
        "Please enter a username and 4-digit passcode",
      );
      return;
    }

    setState(() => _isLoading = true);
    print('passing username: $username and passcode: $_passcode');

    final success = await AuthService().login(username, _passcode);
    print('success: $success');

    setState(() => _isLoading = false);

    if (success) {
      showCustomSnackbar(context, "Login successful!");
      Navigator.pushReplacement(
        context,
        AnimatedPageRoute(
          page: HomeScreen(),
          transitionType: TransitionType.slideFromRight,
        ),
      );
    } else {
      showCustomSnackbar(context, "Login failed. Try again.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: AppHeading(text: 'Welcome Back')),
              const SizedBox(height: 60),

              Text(
                'Username',
                style: Theme.of(
                  context,
                ).textTheme.labelMedium?.copyWith(color: Colors.white),
              ),
              const SizedBox(height: 8),
              AppInputField(
                controller: _usernameController,
                hintText: 'Enter username',
                semanticsLabel: 'Enter your username',
              ),
              const SizedBox(height: 27),

              Text(
                'Passcode',
                style: Theme.of(
                  context,
                ).textTheme.labelMedium?.copyWith(color: Colors.white),
              ),
              const SizedBox(height: 8),
              AppPasscodeField(onChanged: (value) => _passcode = value),
              const SizedBox(height: 35),

              AppButton(
                text: 'Login',
                onPressed: _isLoading ? null : _onLogin,
                isLoading: _isLoading,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
