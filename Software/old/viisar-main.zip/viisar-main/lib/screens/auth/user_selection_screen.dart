import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/auth/new_user.dart';
import 'package:viisar/screens/auth/old_user.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/app_heading.dart';

class UserSelectionScreen extends StatelessWidget {
  const UserSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const AppHeading(text: 'Welcome to Viisar'),
                const SizedBox(height: 80),

                // New User Button
                AppButton(
                  text: 'New User',
                  onPressed: () {
                    Navigator.push(
                      context,
                      AnimatedPageRoute(
                        page: const UsernameGeneratorScreen(),
                        transitionType: TransitionType.fade,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 40),

                // Existing User Button
                AppButton(
                  text: 'Existing User',
                  onPressed: () {
                    Navigator.push(
                      context,
                      AnimatedPageRoute(
                        page: const OldUser(),
                        transitionType: TransitionType.fade,
                      ),
                    );
                  },
                  // Set white background and secondary text color for contrast
                  isLoading: false,
                  // override default colors
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
