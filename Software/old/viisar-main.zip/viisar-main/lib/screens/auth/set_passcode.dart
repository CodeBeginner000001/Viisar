import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/screens/auth/class_select.dart';
import 'package:viisar/services/authorization.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/app_heading.dart';
import 'package:viisar/widgets/app_snackbar.dart';
import 'package:viisar/widgets/app_passcode_field.dart';

class SetPasscodeScreen extends StatefulWidget {
  final String username;
  final String userid;
  const SetPasscodeScreen({
    super.key,
    required this.username,
    required this.userid,
  });

  @override
  State<SetPasscodeScreen> createState() => _SetPasscodeScreenState();
}

class _SetPasscodeScreenState extends State<SetPasscodeScreen> {
  String _passcode = '';
  bool _isLoading = false;

  void _showCustomSnackbar(String message) {
    showCustomSnackbar(context, message);
  }

  void _onSubmit() async {
    if (_passcode.length != 4) {
      _showCustomSnackbar("Please enter a 4-digit passcode");
      return;
    }

    setState(() => _isLoading = true);

    final success = await AuthService().createAccount(widget.userid, _passcode);

    setState(() => _isLoading = false);

    if (success) {
      _showCustomSnackbar("Account created successfully!");

      Navigator.push(
        context,
        AnimatedPageRoute(
          page: ClassSelectionScreen(),
          transitionType: TransitionType.fade,
        ),
      );
    } else {
      _showCustomSnackbar("Failed to create account. Try again.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const AppHeading(text: 'Set Your Passcode'),
              const SizedBox(height: 40),
              AppPasscodeField(onChanged: (value) => _passcode = value),
              const SizedBox(height: 40),
              AppButton(
                text: 'Submit',
                onPressed: _isLoading ? null : _onSubmit,
                isLoading: _isLoading,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
