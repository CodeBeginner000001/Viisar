import 'package:flutter/material.dart';
import 'package:viisar/core/constants/app_colors.dart';
import 'package:viisar/core/constants/app_navigation.dart';
import 'package:viisar/widgets/app_heading.dart';
import 'package:viisar/widgets/app_button.dart';
import 'package:viisar/widgets/app_display_text.dart';
import 'package:viisar/screens/auth/set_passcode.dart';

class UsernameResultScreen extends StatelessWidget {
  final String username;
  final String userid;

  const UsernameResultScreen({
    super.key,
    required this.username,
    required this.userid,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppHeading(text: 'Your Generated Username'),
              const SizedBox(height: 40),
              AppDisplayText(text: username, color: AppColors.primary),
              const SizedBox(height: 60),
              AppButton(
                text: 'Set Your Passcode',
                onPressed: () {
                  Navigator.push(
                    context,
                    AnimatedPageRoute(
                      page: SetPasscodeScreen(
                        username: username,
                        userid: userid,
                      ),
                      transitionType: TransitionType.fade,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
