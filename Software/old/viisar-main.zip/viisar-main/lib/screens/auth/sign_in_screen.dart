// import 'package:flutter/material.dart';
// import 'package:viisar/core/constants/app_colors.dart';
// import 'package:viisar/core/constants/app_text_styles.dart';
// import 'package:viisar/services/auth_service.dart';
// import 'otp_screen.dart';

// class SignInScreen extends StatefulWidget {
//   const SignInScreen({super.key});

//   @override
//   State<SignInScreen> createState() => _SignInScreenState();
// }

// class _SignInScreenState extends State<SignInScreen> {
//   final phoneController = TextEditingController();
//   final FocusNode _phoneFocusNode = FocusNode();
//   bool loading = false;
//   bool _hasError = false;
//   String _errorMessage = '';

//   @override
//   void dispose() {
//     _phoneFocusNode.dispose();
//     phoneController.dispose();
//     super.dispose();
//   }

//   void sendOtp() async {
//     String phoneNumber = phoneController.text.trim();

//     // Check if phone number is empty
//     if (phoneNumber.isEmpty) {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Please enter your phone number';
//       });
//       return;
//     }

//     // Check if phone number is 10 digits
//     if (phoneNumber.length != 10 ||
//         !RegExp(r'^[0-9]{10}$').hasMatch(phoneNumber)) {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Please enter a valid 10-digit phone number';
//       });
//       return;
//     }

//     setState(() {
//       loading = true;
//       _hasError = false;
//     });

//     bool success = await AuthService.sendOtp(phoneNumber);
//     setState(() => loading = false);

//     if (success && mounted) {
//       Navigator.push(
//         context,
//         MaterialPageRoute(builder: (_) => OTPScreen(phone: phoneNumber)),
//       );
//     } else {
//       setState(() {
//         _hasError = true;
//         _errorMessage = 'Failed to send OTP. Please try again.';
//       });

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text(_errorMessage),
//           backgroundColor: Colors.red,
//           behavior: SnackBarBehavior.floating,
//           margin: const EdgeInsets.all(16),
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);

//     return Scaffold(
//       backgroundColor: theme.colorScheme.background,
//       body: Semantics(
//         label: 'Phone number sign in screen',
//         child: SafeArea(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Semantics(
//                   header: true,
//                   child: Text(
//                     'Welcome to Viisar!',
//                     style: AppTextStyles.headlineLarge(
//                       theme.colorScheme.onBackground,
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//                 Semantics(
//                   hint: 'You need to sign in with your phone number',
//                   child: Text(
//                     'Sign in with your phone number',
//                     style: AppTextStyles.titleLarge(
//                       theme.colorScheme.onBackground.withOpacity(0.9),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 40),
//                 Semantics(
//                   label: 'Phone number input field',
//                   textField: true,
//                   hint: 'Enter your 10-digit phone number',
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Phone Number',
//                         style: AppTextStyles.labelMedium(
//                           theme.colorScheme.onBackground,
//                         ),
//                       ),
//                       const SizedBox(height: 8),
//                       TextFormField(
//                         controller: phoneController,
//                         focusNode: _phoneFocusNode,
//                         keyboardType: TextInputType.phone,
//                         style: AppTextStyles.inputField(
//                           theme.colorScheme.onSurface,
//                         ),
//                         decoration: InputDecoration(
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(20),
//                             borderSide: BorderSide.none,
//                           ),
//                           enabledBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(20),
//                             borderSide: BorderSide(
//                               color: Colors.grey.shade300,
//                               width: 2,
//                             ),
//                           ),
//                           focusedBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(20),
//                             borderSide: BorderSide(
//                               color: AppColors.primary,
//                               width: 2,
//                             ),
//                           ),
//                           errorBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(20),
//                             borderSide: const BorderSide(
//                               color: Colors.red,
//                               width: 2,
//                             ),
//                           ),
//                           fillColor:
//                               _hasError
//                                   ? Colors.red.withOpacity(0.05)
//                                   : theme.colorScheme.surface,
//                           filled: true,
//                           hintText: 'Enter phone number',
//                           hintStyle: AppTextStyles.titleLarge(
//                             Colors.grey.shade500,
//                           ),
//                           contentPadding: const EdgeInsets.symmetric(
//                             vertical: 20,
//                             horizontal: 16,
//                           ),
//                           prefixIcon: Icon(
//                             Icons.phone_android,
//                             color:
//                                 _phoneFocusNode.hasFocus
//                                     ? AppColors.primary
//                                     : Colors.grey,
//                             size: 26,
//                           ),
//                           suffixIcon:
//                               phoneController.text.isNotEmpty
//                                   ? IconButton(
//                                     icon: const Icon(Icons.clear, size: 24),
//                                     onPressed: () {
//                                       phoneController.clear();
//                                       setState(() {
//                                         _hasError = false;
//                                       });
//                                     },
//                                     tooltip: 'Clear phone number',
//                                   )
//                                   : null,
//                           isDense: true,
//                         ),
//                         onChanged: (value) {
//                           setState(() {
//                             _hasError = false;
//                           });
//                         },
//                       ),
//                       if (_hasError)
//                         Padding(
//                           padding: const EdgeInsets.only(top: 8.0, left: 8.0),
//                           child: Text(
//                             _errorMessage,
//                             style: AppTextStyles.errorText(),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//                 const SizedBox(height: 48),
//                 Semantics(
//                   label: 'Send OTP button',
//                   button: true,
//                   enabled: !loading,
//                   hint: 'Double tap to send verification code to your phone',
//                   child: SizedBox(
//                     width: double.infinity,
//                     height: 64,
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: AppColors.primary,
//                         foregroundColor: Colors.white,
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         elevation: 2,
//                         padding: const EdgeInsets.symmetric(vertical: 12),
//                       ),
//                       onPressed: loading ? null : sendOtp,
//                       child:
//                           loading
//                               ? Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   const SizedBox(
//                                     width: 24,
//                                     height: 24,
//                                     child: CircularProgressIndicator(
//                                       color: Colors.white,
//                                       strokeWidth: 3,
//                                     ),
//                                   ),
//                                   const SizedBox(width: 16),
//                                   Text(
//                                     'Sending...',
//                                     style: AppTextStyles.buttonText(
//                                       Colors.white,
//                                     ),
//                                   ),
//                                 ],
//                               )
//                               : Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   const Icon(Icons.send, size: 24),
//                                   const SizedBox(width: 12),
//                                   Text(
//                                     'Send OTP',
//                                     style: AppTextStyles.buttonText(
//                                       Colors.white,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//                 Center(
//                   child: TextButton(
//                     onPressed: () {},
//                     child: Text(
//                       'Need help?',
//                       style: AppTextStyles.labelMedium(AppColors.primary),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
