// import 'package:http/http.dart' as http;
// import 'dart:convert';

// import 'package:viisar/services/shared_pref.dart';

// class AuthService {
//   static const String baseUrl = 'https://your-api-url.com/api';

//   static Future<bool> sendOtp(String phone) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/send-otp'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'phonenumber': phone}),
//       );

//       return response.statusCode == 200;
//     } catch (e) {
//       print('Error sending OTP: $e');
//       return false;
//     }
//   }

//   static Future<Map<String, dynamic>> verifyOtp(
//     String phone,
//     String otp,
//   ) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/verify-otp'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'phonenumber': phone, 'otp': otp}),
//       );

//       if (response.statusCode == 200) {
//         final body = jsonDecode(response.body);
//         final data = body['data'];

//         final token = data['token'];
//         final user = data['user'];
//         final userId = user['id'];
//         final userPhone = user['phonenumber'];

//         await SharedPrefsService.saveUserData(
//           token: token,
//           userId: userId,
//           phone: userPhone,
//         );

//         // Return a map with 'verified' and 'user' data
//         return {'verified': true, 'user': user};
//       } else {
//         print('OTP verification failed. Status: ${response.statusCode}');
//         return {'verified': false}; // Return false if verification fails
//       }
//     } catch (e) {
//       print('Error verifying OTP: $e');
//       return {'verified': false}; // Return false if an error occurs
//     }
//   }

//   static Future<bool> saveUserDetails(
//     String phone,
//     Map<String, dynamic> details,
//   ) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/save-user'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'phone': phone, ...details}),
//       );

//       return response.statusCode == 200;
//     } catch (e) {
//       print('Error saving user details: $e');
//       return false;
//     }
//   }

//   static Future<bool> logout() async {
//     try {
//       // Clear the stored user data (token, user ID, phone)
//       await SharedPrefsService.clearUserData();

//       // Optionally, perform any other logout tasks (e.g., redirect to login screen)
//       // For example, you could navigate to the login page after logout:
//       // Get.offAll(() => LoginPage());

//       return true;
//     } catch (e) {
//       print('Error logging out: $e');
//       return false;
//     }
//   }
// }
