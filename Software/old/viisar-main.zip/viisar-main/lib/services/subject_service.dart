import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:viisar/models/chapter_model.dart';
import 'package:viisar/models/subject_model.dart';
import 'package:viisar/models/topic_model.dart';

import 'package:viisar/services/shared_pref.dart';

class SubjectService {
  final String baseUrl = 'https://neenva-backend.onrender.com/api';

  // Fetch subjects by class ID and return a list of Subject objects
  Future<List<Subject>> fetchSubjectsByClassId(String classId) async {
    final token = await SharedPrefsService.getToken();
    if (token == null) return [];

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/subject/$classId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> subjects = data['data'];

        return subjects
            .map((subjectJson) => Subject.fromJson(subjectJson))
            .toList();
      } else {
        throw Exception('Failed to load subjects');
      }
    } catch (e) {
      throw Exception('Error fetching subjects: $e');
    }
  }

  // Fetch chapters by subject ID and return a list of Chapter objects
  Future<List<Chapter>> fetchChaptersBySubject(String subjectId) async {
    final token = await SharedPrefsService.getToken();
    if (token == null) return [];

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/chapter/$subjectId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> chapters = data['data'];

        return chapters
            .map((chapterJson) => Chapter.fromJson(chapterJson))
            .toList();
      } else {
        throw Exception('Failed to load chapters');
      }
    } catch (e) {
      throw Exception('Error fetching chapters: $e');
    }
  }

  // Fetch topics by chapter ID and return a list of Topic objects
  Future<List<Topic>> fetchTopicsByChapterId(String chapterId) async {
    final token = await SharedPrefsService.getToken();
    if (token == null) return [];

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/topic/$chapterId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> topics = data['data'];

        return topics.map((topicJson) => Topic.fromJson(topicJson)).toList();
      } else {
        throw Exception('Failed to load topics');
      }
    } catch (e) {
      throw Exception('Error fetching topics: $e');
    }
  }
}
