import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:viisar/models/history_model.dart';
import 'package:viisar/services/shared_pref.dart';

class BookmarkService {
  static const String baseUrl = 'https://neenva-backend.onrender.com/api';

  static Future<bool> updateBookmark(String topicId) async {
    final token = await SharedPrefsService.getToken();
    if (token == null || token.isEmpty) return false;

    final url = Uri.parse('$baseUrl/history/update');
    final response = await http.put(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'topicId': topicId}),
    );

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      return responseData['success'] == true;
    } else {
      print('Update failed: ${response.statusCode} - ${response.body}');
      return false;
    }
  }

  static Future<HistoryModel?> getBookmark() async {
    final token = await SharedPrefsService.getToken();
    if (token == null || token.isEmpty) return null;

    final url = Uri.parse('$baseUrl/history/get-history');
    final response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      if (jsonData['success'] == true && jsonData['data'] != null) {
        return HistoryModel.fromJson(jsonData['data']);
      }
    } else {
      print('Get history failed: ${response.statusCode} - ${response.body}');
    }
    return null;
  }
}
