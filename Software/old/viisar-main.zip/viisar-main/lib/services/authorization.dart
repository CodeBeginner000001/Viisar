import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:viisar/screens/auth/user_selection_screen.dart';
import 'package:viisar/services/shared_pref.dart';

class AuthService {
  final String baseUrl = 'https://neenva-backend.onrender.com/api/user';

  /// Step 1: Generate Username from Name
  Future<Map<String, String>?> generateUsername(String name) async {
    final url = Uri.parse('$baseUrl/signup/username');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'name': name}),
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        final userId = data['data']['userId'];
        final username = data['data']['username'];

        return {'userId': userId, 'username': username};
      } else {
        print('Username generation failed: ${response.body}');
        return null;
      }
    } catch (e) {
      print('Error generating username: $e');
      return null;
    }
  }

  /// Step 2: Set Password
  Future<bool> createAccount(String userId, String password) async {
    final url = Uri.parse('$baseUrl/signup/password');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'userId': userId, 'password': password}),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final token = responseData['data']['token'];
        final user = responseData['data']['user'];

        await SharedPrefsService.saveUserData(
          token: token,
          userId: user['id'],
          classId: '',
          username: user['username'],
        );

        return true;
      } else {
        print('Password setup failed: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error setting password: $e');
      return false;
    }
  }

  /// Step 3: Login with Username and Passcode
  Future<bool> login(String username, String passcode) async {
    final url = Uri.parse('$baseUrl/login');

    try {
      print('Logging in with username: $username and passcode: $passcode');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': passcode}),
      );
      print('statusCode: ${response.statusCode}');
      print('Response: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final data = responseData['data'];
        final token = data['token'];
        final user = data['user'];
        final userId = user['id'];
        final classId = user['classId'];

        await SharedPrefsService.saveUserData(
          token: token,
          userId: userId,
          classId: classId,
          username: username,
        );

        return true;
      } else {
        print('Login failed: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error during login: $e');
      return false;
    }
  }

  Future<void> logout(BuildContext context) async {
    try {
      await SharedPrefsService.clearUserData();

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => UserSelectionScreen()),
      );
    } catch (e) {
      print('Error logging out: $e');
    }
  }
}
