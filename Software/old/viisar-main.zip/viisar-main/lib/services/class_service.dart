import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:viisar/models/class_model.dart';

class ClassService {
  static const String _classUrl =
      'https://neenva-backend.onrender.com/api/class';
  static const String _updateProfileUrl =
      'https://neenva-backend.onrender.com/api/user/update-profile';

  /// Fetch all classes from the server
  static Future<List<Class>> fetchAllClasses() async {
    try {
      final token = await _getToken();
      if (token == null) throw Exception('Auth token not found');

      print('Fetching classes with token: $token');

      final response = await http.get(
        Uri.parse(_classUrl),
        headers: {'Authorization': 'Bearer $token'},
      );

      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final List<dynamic> classList = body['data'];
        return classList.map((json) => Class.fromJson(json)).toList();
      } else {
        throw Exception(
          'Failed to load classes: ${response.statusCode} ${response.body}',
        );
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Update user's selected class
  static Future<bool> updateClass(String classId) async {
    try {
      final token = await _getToken();
      if (token == null) throw Exception('Auth token not found');

      final response = await http.post(
        Uri.parse(_updateProfileUrl),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'classId': classId}),
      );

      print('Update Status Code: ${response.statusCode}');
      print('Update Response Body: ${response.body}');

      return response.statusCode == 200;
    } catch (e) {
      print('Error updating class: $e');
      return false;
    }
  }

  static Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }
}
