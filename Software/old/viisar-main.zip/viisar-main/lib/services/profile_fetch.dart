import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:viisar/services/shared_pref.dart';

class UserService {
  static Future<Map<String, dynamic>?> getUserDetails() async {
    final token = await SharedPrefsService.getToken();

    if (token == null) return null;

    final url = Uri.parse(
      'https://neenva-backend.onrender.com/api/user/profile',
    );

    try {
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      print('User Details Status: ${response.statusCode}');
      print('User Details Body: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        return responseData['data'];
      }
    } catch (e) {
      print('Error fetching user details: $e');
    }

    return null;
  }
}
