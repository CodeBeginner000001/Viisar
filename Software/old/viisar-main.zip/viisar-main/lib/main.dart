import 'package:flutter/material.dart';
import 'package:viisar/core/constants/theme.dart';
import 'package:viisar/screens/home/splashscreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Viisar',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      theme: darkTheme,
      home: Splashscreen(),
    );
  }
}
